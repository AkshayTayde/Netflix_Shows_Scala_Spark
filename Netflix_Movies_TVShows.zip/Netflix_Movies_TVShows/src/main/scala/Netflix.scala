//import important libraries
import org.apache.spark.sql.SparkSession


object Netflix {
  def main(args:Array[String]):Unit ={

// Initialize Spark Session
    val spark = SparkSession.builder()
      .appName(name="TV_Movies")
      .master("local")
      .getOrCreate()

    val df = spark.read.option("header","true").csv("/Users/akshaytayde/Desktop/netflix_titles.csv")
    df.show()

// Data Wrangling

    df.describe().show()



    df.createOrReplaceTempView("netflix")

    //Data Exploration
   // 1. No. of movies released in 2021 from Mexico country
    val r = spark.sql(
      """select count(*)
      from netflix
      where country = 'Mexico'
      and type= 'Movie'
      and release_year = 2021
      """)
    r.show()
// 2. Display country column only
    df.select("country").show()

//3. count the no. of shows according to their type
    df.groupBy("type").count().show()

//4. Movie rating analysis
    df.groupBy("rating").count().show()

    //5.Oldest Movies
    df.select("title","release_year").orderBy("release_year").show()

    //6.List of the movies released in 2020
    df.select("title","release_year").distinct().where("release_year==2020").show()

//7. total no. of release year
    spark.sql("""Select
      count(distinct release_year) as count_of_release_year
        from netflix
        limit 1""").show()
  }
}
